from aws_cdk import (
    Stack,
    aws_s3 as s3,
    aws_glue as glue,
    RemovalPolicy,
)
from constructs import Construct

class AnalyticsStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        bucket = s3.Bucket(
            self,
            "AnalyticsBucket",
            removal_policy=RemovalPolicy.DESTROY,
            auto_delete_objects=True,
        )

        database = glue.CfnDatabase(
            self,
            "AnalyticsDB",
            catalog_id=self.account,
            database_input={"name": "analytics_db"}
        )

        glue.CfnTable(
            self,
            "SalesDataTable",
            catalog_id=self.account,
            database_name=database.ref,
            table_input={
                "name": "sales_data",
                "storageDescriptor": {
                    "columns": [
                        {"name": "order_id", "type": "string"},
                        {"name": "date", "type": "string"},
                        {"name": "region", "type": "string"},
                        {"name": "product", "type": "string"},
                        {"name": "quantity", "type": "int"},
                        {"name": "revenue", "type": "double"},
                    ],
                    "location": bucket.s3_url_for_object("raw/"),
                    "inputFormat": "org.apache.hadoop.mapred.TextInputFormat",
                    "outputFormat": "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat",
                    "serdeInfo": {
                        "serializationLibrary": "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"
                    },
                },
            },
        )

        self.bucket_name_output = cdk.CfnOutput(
            self, "BucketName", value=bucket.bucket_name
        )