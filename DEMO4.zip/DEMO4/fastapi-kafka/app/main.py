from fastapi import FastAPI
from confluent_kafka import Producer
import socket

app = FastAPI()

conf = {'bootstrap.servers': "localhost:9092",
        'client.id': socket.gethostname()}
producer = Producer(conf)

@app.post("/produce/")
async def produce_message(message: str):
    topic = "test-topic"
    producer.produce(topic, key="key", value=message)
    producer.flush()
    return {"status": "Message sent", "message": message}
