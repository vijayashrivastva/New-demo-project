from fastapi import FastAPI
import pymysql
import os
import psycopg2

app = FastAPI()

# DB_CONFIG
DB_CONFIG = {
            "dbname": "demo",
            "user": "postgres",
            "password": "postgres",
            "host": "localhost",   # or the DB host
            "port": "5432"
        }

@app.get("/")
def root():
    return {"message": "FastAPI Serverless CDK Example"}

@app.get("/users")
def get_users():
    conn = psycopg2.connect(**DB_CONFIG)
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM users;")
        users = cursor.fetchall()
    return {"users": users}
