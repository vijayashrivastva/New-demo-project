#!/usr/bin/env python3
import aws_cdk as cdk
from stacks.fastapi_stack import FastAPIStack

app = cdk.App()
FastAPIStack(app, "FastAPIServerlessStack")
app.synth()
