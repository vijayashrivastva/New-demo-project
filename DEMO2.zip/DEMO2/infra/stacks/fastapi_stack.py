
from aws_cdk import (
    Stack,
    aws_lambda as _lambda,
    aws_apigateway as apigw,
    aws_rds as rds,
    aws_ec2 as ec2,
)
from constructs import Construct

class FastAPIStack(Stack):
    def __init__(self, scope: Construct, id: str, **kwargs):
        super().__init__(scope, id, **kwargs)

        vpc = ec2.Vpc(self, "FastAPIVPC", max_azs=2)

        db = rds.DatabaseInstance(
            self, "FastAPIMySQL",
            engine=rds.DatabaseInstanceEngine.mysql(
                version=rds.MysqlEngineVersion.VER_8_0_36
            ),
            vpc=vpc,
            credentials=rds.Credentials.from_generated_secret("admin"),
            instance_type=ec2.InstanceType.of(
                ec2.InstanceClass.BURSTABLE3, ec2.InstanceSize.MICRO
            ),
            multi_az=False,
            allocated_storage=20,
            removal_policy=cdk.RemovalPolicy.DESTROY,
            deletion_protection=False,
            publicly_accessible=False,
        )

        lambda_fn = _lambda.Function(
            self, "FastAPIFunction",
            runtime=_lambda.Runtime.PYTHON_3_11,
            handler="main.handler",
            code=_lambda.Code.from_asset("../app"),
            environment={
                "DB_HOST": db.db_instance_endpoint_address,
                "DB_USER": "admin",
                "DB_PASSWORD": db.secret.secret_value_from_json("password").unsafe_unwrap(),
                "DB_NAME": "fastapi_demo",
            }
        )

        db.connections.allow_default_port_from(lambda_fn)

        api = apigw.LambdaRestApi(
            self, "FastAPIEndpoint",
            handler=lambda_fn,
            proxy=True
        )
